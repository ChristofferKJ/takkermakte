﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelBureauWPF
{
    [Serializable]
    public class Model
    {
        string name;
        string phonenumber;
        string address; 
        string height;
        string weight;
        string haircolor;
        string comments;
        ModelJobs modeljobs; 

        public Model()
        { }

        public Model
            (string _Name, 
            string _Phonenumber, 
            string _Address, 
            string _Height, 
            string _Weight, 
            string _HairColor,
            string _Comments)
        {
            name = _Name;
            phonenumber = _Phonenumber;
            address = _Address;
            height = _Height;
            weight = _Weight;
            haircolor = _HairColor;
            comments = _Comments; 
        }

        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value; 
            }
        }
                
      
        public string Phonenumber
        {
            get
            {
                return phonenumber;
            }
            set
            {
                phonenumber = value; 
            }
        }

        public string Address
        {
            get
            {
                return address; 
            }
            set
            {
                address = value; 
            }
        }

        public string Height
        {
            get
            {
                return height;
            }
            set
            {
                height = value; 
            }
        }

        public string Weight
        {
            get
            {
                return weight;
            }
            set
            {
                weight = value; 
            }

        }
        public string Haircolor
        {
            get
            {
                return haircolor;
            }
            set
            {
                haircolor = value; 
            }
        }

        public string Comments
        {
            get
            {
                return comments; 
            }
            set
            {
                comments = value; 
            }
        }

        public ModelJobs ModelJob
        {
            get
            {
                return modeljobs; 
            }

            set
            {
                modeljobs = value; 
            }
        }

    }
}
