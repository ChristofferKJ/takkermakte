﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModelBureauWPF
{
    [Serializable]
    public class ModelJobs
    {
        string nameofcustomer;
        string startdate;
        string amountofdays; 
        string location;
        string amountofmodels;
        string comments;
        Model assignedmodel; 

        public ModelJobs()
        { }

        public ModelJobs(string _NameOfCustomer, 
            string _Startdate, 
            string _AmountOfDays, 
            string _Location, 
            string _AmountOfModels, 
            string _Comments)
        {
            nameofcustomer = _NameOfCustomer;
            startdate = _Startdate;
            amountofdays = _AmountOfDays;
            location = _Location;
            amountofmodels = _AmountOfModels;
            comments = _Comments; 
        }

        public string NameOfCustomer
        {
            get
            {
                return nameofcustomer; 
            }
            set
            {
                nameofcustomer = value; 
            }

        }

        public string Location
        {
            get { return location; }
            set { location = value;  }
        }
            
       public string Startdate {
            get
            {
                return startdate;
            }

            set
            {
                startdate = value;
            }    

                }
        public string AmountOfDays
        {
            get { return amountofdays; }
            set { amountofdays = value; }
        }
   
        public string AmountOfModels
        {
            get
            {
                return amountofmodels;
            }
            set { amountofmodels = value;  }
        }
        public string Comments {
        get{ return comments; }
        set { comments = value;  }
        }

        public Model AssignedModel
        {
            get { return assignedmodel;  }
            set { assignedmodel = value;  }
        }
    }
}
    